from copy import deepcopy
from io import BytesIO
from pathlib import Path
import argparse
import json

from PIL import Image, ImageOps
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.oxml.ns import qn
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Pt


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--templates-dir", type=Path, default=ROOT / "bakashot/templates")
parser.add_argument("--backgrounds-dir", type=Path, required=True)
parser.add_argument("--output-dir", type=Path, required=True)
parser.add_argument("--format", choices=("A4", "Wide"), help="Rebuild only this format")
args = parser.parse_args()
args.output_dir.mkdir(parents=True, exist_ok=True)
layout = json.loads((ROOT / "bakashot/browser-layout.json").read_text())
variants = [
    ("A4-Color", "A4", "Bakashot-background-A4.png"),
    ("Wide-Color", "Wide", "Bakashot-background-WhatsApp.png"),
    ("A4-Black-and-White", "A4", "Bakashot-background-A4-Black-and-White.png"),
]


def replace_picture(slide, picture, data):
    blip = picture._element.blipFill.blip
    previous = blip.get(qn("r:embed"))
    _, current = slide.part.get_or_add_image_part(BytesIO(data))
    blip.set(qn("r:embed"), current)
    if previous != current:
        slide.part.drop_rel(previous)


def lock_background(shape):
    if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
        parent = shape._element.xpath("./p:nvGrpSpPr/p:cNvGrpSpPr")[0]
        tag = "a:grpSpLocks"
    else:
        parent = shape._element.xpath("./p:nvPicPr/p:cNvPicPr")[0]
        tag = "a:picLocks"
    locks = parent.find(qn(tag))
    if locks is None:
        locks = OxmlElement(tag)
        parent.append(locks)
    for attribute in ("noSelect", "noMove", "noResize"):
        locks.set(attribute, "1")


for suffix, format_name, background_name in variants:
    if args.format and args.format != format_name:
        continue
    variant_layout = {**layout[format_name], **layout.get(suffix, {})}
    source = args.templates_dir / f"Bakashot-Full-Editable-{suffix}.pptx"
    presentation = Presentation(source)
    assert len(presentation.slides) == 1
    slide = presentation.slides[0]
    background_data = (args.backgrounds_dir / format_name / background_name).read_bytes()
    background = slide.shapes[0]
    assert background.name.startswith("Decorative background")
    if background.shape_type == MSO_SHAPE_TYPE.GROUP:
        slide.shapes._spTree.remove(background._element)
        background = slide.shapes.add_picture(
            BytesIO(background_data), 0, 0,
            width=presentation.slide_width, height=presentation.slide_height,
        )
        slide.shapes._spTree.remove(background._element)
        slide.shapes._spTree.insert(2, background._element)
    else:
        replace_picture(slide, background, background_data)
    background.name = "Decorative background - fixed; edit using the background code"
    lock_background(background)
    monochrome = suffix.endswith("Black-and-White")
    for shape in slide.shapes:
        if not shape.has_text_frame or not shape.text:
            continue
        if shape.name == "רח׳ רבי יהודה הנשיא 20, פתח תקווה":
            shape.name = "רבי יהודה הנשיא 20, פתח תקווה"
            for paragraph in shape.text_frame.paragraphs:
                for run in paragraph.runs:
                    run.text = run.text.replace("רח׳ רבי יהודה הנשיא", "רבי יהודה הנשיא")
        override = variant_layout.get(shape.name)
        if override:
            shape.left, shape.top, shape.width, shape.height = [
                round(value * presentation.slide_width / 794) for value in override["bounds"]
            ]
            if "size" in override:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size = Pt(override["size"] * presentation.slide_width / 914400 / 794 * 72)
        for paragraph in shape.text_frame.paragraphs:
            if monochrome:
                for run in paragraph.runs:
                    run.font.color.rgb = RGBColor(0, 0, 0)
            properties = paragraph.runs[0]._r.get_or_add_rPr()
            for parent, tag in [
                (paragraph._p.get_or_add_pPr(), "a:defRPr"),
                (paragraph._p, "a:endParaRPr"),
            ]:
                previous = parent.find(qn(tag))
                if previous is not None:
                    parent.remove(previous)
                defaults = deepcopy(properties)
                defaults.tag = qn(tag)
                parent.append(defaults)
    oud = next(shape for shape in slide.shapes
               if shape.shape_type == MSO_SHAPE_TYPE.PICTURE and shape != background
               and Image.open(BytesIO(shape.image.blob)).height > 1.5 *
               Image.open(BytesIO(shape.image.blob)).width)
    oud.left, oud.top, oud.width, oud.height = [
        round(value * presentation.slide_width / 794)
        for value in variant_layout["oud"]["bounds"]
    ]
    if monochrome:
        image = Image.open(BytesIO(oud.image.blob)).convert("RGBA")
        gray = ImageOps.autocontrast(image.convert("L"), cutoff=1, mask=image.getchannel("A"))
        gray = gray.point([round(255 * (value / 255) ** 1.25) for value in range(256)])
        photo = Image.merge("RGBA", (gray, gray, gray, image.getchannel("A")))
        data = BytesIO()
        photo.save(data, format="PNG")
        replace_picture(slide, oud, data.getvalue())
    full_path = args.output_dir / f"Bakashot-Full-Editable-{suffix}.pptx"
    presentation.save(full_path)
    static = [shape for shape in slide.shapes if shape.name not in {"parashah", "rabbi"}]
    group = slide.shapes.add_group_shape(static)
    group.name = "Fixed artwork and event details - edit the Full-Editable version"
    lock_background(group)
    for shape in group.shapes:
        if shape.has_text_frame:
            parent = shape._element.xpath("./p:nvSpPr/p:cNvSpPr")[0]
            locks = parent.find(qn("a:spLocks"))
            if locks is None:
                locks = OxmlElement("a:spLocks")
                parent.append(locks)
            for attribute in ("noSelect", "noMove", "noResize", "noTextEdit"):
                locks.set(attribute, "1")
    slide.shapes._spTree.remove(group._element)
    slide.shapes._spTree.insert(2, group._element)
    notes = slide.notes_slide.notes_text_frame
    notes.text = (
        "Weekly browser template: only שם הפרשה and שם הרב are editable. "
        "All other content is a protected background group. For other changes, "
        "use the separate Full-Editable presentation or background source code.\n\n"
        + notes.text
    )
    weekly_path = args.output_dir / f"Bakashot-Weekly-{suffix}.pptx"
    presentation.save(weekly_path)
    for path in (full_path, weekly_path):
        restored = Presentation(path)
        assert len(restored.slides) == 1
        fields = [shape for shape in restored.slides[0].shapes
                  if shape.has_text_frame and shape.text]
        assert len(fields) == (2 if path == weekly_path else 18)
        assert {"parashah", "rabbi"} <= {shape.name for shape in fields}
        print(path.name)
