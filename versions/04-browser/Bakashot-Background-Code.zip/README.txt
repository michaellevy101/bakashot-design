Bakashot background source

The regular PowerPoint templates keep their decorative background protected.
This separate source package lets a designer update it without complicating
the weekly name-editing workflow.

Requirements: Python 3, Pillow, python-pptx.
Install the dependencies:
    python3 -m pip install Pillow python-pptx

Run from this extracted folder:

A4:
    python3 create_bakashot.py --variant gold-medallion --a4 --starry --browser-fonts --strong-print --qr-source bakashot/assets/whatsapp-qr.png --output-dir output/A4

Wide:
    python3 create_bakashot.py --variant gold-medallion --landscape --starry --browser-fonts --qr-source bakashot/assets/whatsapp-qr.png --output-dir output/Wide

Rebuild all six browser presentations after generating both backgrounds:
    python3 rebuild_bakashot_browser.py --backgrounds-dir output --output-dir presentations

The three input presentations in bakashot/templates preserve the manually
edited typography and content. The exact A4 address and wide title/year
adjustments are recorded in bakashot/browser-layout.json and replayed by
both scripts. Edit that file to make future layout changes reproducible.
The A4 colour and black-and-white oud sizes and positions preserve the user's
separate manual enlargements exactly. The print-specific oud geometry is in
the A4-Black-and-White section of browser-layout.json. The wide oud retains
its 20% enlargement. The address omits the "street" prefix.
The wide left-column event text is larger, with tighter vertical spacing.
The A4 lower section also has substantially larger supporting text and names.
The latest manually adjusted Torah/rabbi and singers spacing is shared by
all four A4 presentations, while each colour variant keeps its own oud geometry.
To rebuild only those four copies, add --format A4 to the rebuild command.

Every presentation uses the same continuous interlaced side ornament.
The print background is pure black on white, with thicker clear lines.
Print text is solid black; the oud retains grayscale detail with stronger
contrast.

Weekly copies expose only the two name fields. All other objects are combined
into one protected background group so the cloud-font text stays sharp while
editing remains simple. Use Full-Editable copies to change other event details.

The --output-dir argument writes a separate export. It does not overwrite
the approved files.

Background code to edit:
    illustrated_background: colours, lighting and star density
    title_arch: gold title frame
    decoration_paths and lattice_paths: ornaments and side decorations
    ribbon_polygons: year ribbon and light information panel
    panel_dividers: divider between the time and parashah

Bakashot-background-A4.png or Bakashot-background-WhatsApp.png contains
decoration only. Event text, the oud photograph and the QR code are separate
objects in the full-editing presentations.

The --browser-fonts option uses Microsoft's FrankRuehl and Arial and the
manually adjusted layout. Omitting it retains the original Frank Ruhl Libre
and Heebo typography. Browser fonts are rendered by PowerPoint; they do not
need to be installed to generate the PPTX files.

Photo credit and sharing requirements are in bakashot/assets/PHOTO-LICENSE.txt.
The font licences are included beside their font files.
