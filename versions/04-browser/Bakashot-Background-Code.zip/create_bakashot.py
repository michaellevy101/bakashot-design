from pathlib import Path
from copy import deepcopy
import argparse
import base64
import html
import json
import math
import random
import shutil

from PIL import Image, ImageDraw, ImageFilter
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--alternative", action="store_true")
parser.add_argument("--reference-style", action="store_true")
parser.add_argument("--variant", choices=("royal-arch", "piyut-scroll", "gold-medallion"))
parser.add_argument("--compact", action="store_true")
parser.add_argument("--a4", action="store_true")
parser.add_argument("--landscape", action="store_true")
parser.add_argument("--starry", action="store_true", help="Create a separate starry-sky A4 or landscape version")
parser.add_argument("--weekly-template", action="store_true", help="Leave only the parashah and rabbi fields editable")
parser.add_argument("--template-color-background", type=Path, help="Rendered blank color template for locked PowerPoint export")
parser.add_argument("--template-print-background", type=Path, help="Rendered blank monochrome template for locked PowerPoint export")
parser.add_argument("--output-dir", type=Path, help="Write a separate export without changing approved versions")
parser.add_argument("--qr-source", type=Path, help="Use an existing QR image instead of cropping the original poster")
parser.add_argument("--browser-fonts", action="store_true", help="Use cloud fonts and the manually adjusted browser layout")
parser.add_argument("--strong-print", action="store_true", help="Use matching solid-black background paths for clear printing")
args = parser.parse_args()
if args.compact and args.variant != "gold-medallion":
    parser.error("--compact requires --variant gold-medallion")
if args.a4 and (args.variant != "gold-medallion" or args.compact):
    parser.error("--a4 requires --variant gold-medallion and cannot be combined with --compact")
if args.landscape and (args.variant != "gold-medallion" or args.compact or args.a4):
    parser.error("--landscape requires --variant gold-medallion and cannot be combined with --compact or --a4")
if args.starry and not (args.a4 or args.landscape):
    parser.error("--starry requires --a4 or --landscape")
if args.weekly_template and not args.starry:
    parser.error("--weekly-template requires --starry")
if args.template_color_background and not args.weekly_template:
    parser.error("--template-color-background requires --weekly-template")
if args.template_print_background and not (args.weekly_template and args.template_color_background):
    parser.error("--template-print-background requires --weekly-template and --template-color-background")
if args.template_color_background and args.a4 and not args.template_print_background:
    parser.error("A4 locked PowerPoint export also requires --template-print-background")
if args.browser_fonts and not (args.starry and (args.a4 or args.landscape)):
    parser.error("--browser-fonts requires --starry and --a4 or --landscape")
if args.strong_print and not args.a4:
    parser.error("--strong-print requires --a4")
ALTERNATIVE = args.alternative
VARIANT = args.variant
COMPACT = args.compact
A4_LAYOUT = args.a4
LANDSCAPE = args.landscape
STARRY = args.starry
WEEKLY_TEMPLATE = args.weekly_template
WEEKLY_FIELDS = {"פרשת לך לך": ("parashah", "שם הפרשה"), "הרב יוסף עיני": ("rabbi", "שם הרב")}
BROWSER_LAYOUT = json.loads((ROOT / "bakashot/browser-layout.json").read_text()) if args.browser_fonts else {}
WHATSAPP_HEIGHT = 447 if LANDSCAPE else 1123 if A4_LAYOUT else 794 if COMPACT else 993
REFERENCE_STYLE = args.reference_style or VARIANT is not None
OUT = ROOT / "bakashot"
if VARIANT:
    OUT /= "Collection"
    OUT /= {"royal-arch": "01-Royal-Arch", "piyut-scroll": "02-Piyut-Scroll",
            "gold-medallion": "03-Gold-Medallion"}[VARIANT]
elif REFERENCE_STYLE:
    OUT /= "V3"
elif ALTERNATIVE:
    OUT /= "V2"
if COMPACT:
    OUT /= "WhatsApp-Square"
elif A4_LAYOUT:
    OUT /= "A4-Updated"
elif LANDSCAPE:
    OUT /= "Landscape-Art"
if STARRY:
    OUT /= "Starry-Sky"
if WEEKLY_TEMPLATE:
    OUT /= "Weekly-Template"
if args.output_dir:
    OUT = args.output_dir.resolve()
SOURCE = Path.home() / "Downloads/Green White Illustrated Floral Background A4 Document.png"
OUT.mkdir(parents=True, exist_ok=True)
if ALTERNATIVE or REFERENCE_STYLE:
    shutil.copytree(ROOT / "bakashot" / "fonts", OUT / "fonts", dirs_exist_ok=True)

# Keep the original QR pixels, including a white quiet zone.
if args.qr_source:
    Image.open(args.qr_source).convert("RGB").save(OUT / "whatsapp-qr.png")
else:
    Image.open(SOURCE).crop((18, 1727, 264, 1970)).save(OUT / "whatsapp-qr.png")
QR_DATA = base64.b64encode((OUT / "whatsapp-qr.png").read_bytes()).decode()
if A4_LAYOUT or LANDSCAPE:
    photo = Image.open(ROOT / "bakashot/assets/oud-mim.jpg").convert("RGBA")
    mask = Image.new("L", photo.size)
    contour = [
        (175, 12), (214, 12), (217, 30), (240, 24), (248, 31), (250, 49),
        (244, 64), (219, 66), (224, 150), (246, 203), (280, 241), (316, 318),
        (340, 388), (349, 463), (347, 529), (323, 574), (279, 606), (224, 624),
        (185, 627), (144, 619), (107, 599), (76, 567), (55, 527), (42, 480),
        (40, 426), (49, 375), (66, 314), (90, 264), (119, 216), (161, 167),
        (163, 65), (151, 67), (143, 58), (141, 35), (145, 22), (154, 18),
        (164, 23), (173, 30),
    ]
    ImageDraw.Draw(mask).polygon(
        [(x * photo.width / 383, y * photo.height / 640) for x, y in contour], fill=255
    )
    # Remove the yellow museum backdrop, including gaps between tuning pegs.
    pixels = photo.load()
    alpha = mask.load()
    for y in range(photo.height):
        for x in range(photo.width):
            r, g, b, _ = pixels[x, y]
            if g > 65 and g > r * .78 and b < g * .35:
                alpha[x, y] = 0
    photo.putalpha(mask.filter(ImageFilter.GaussianBlur(.6)))
    photo.save(OUT / "oud-photo.png")
    gray = photo.convert("L")
    Image.merge("RGBA", (gray, gray, gray, photo.getchannel("A"))).save(OUT / "oud-photo-gray.png")
    shutil.copyfile(ROOT / "bakashot/assets/PHOTO-LICENSE.txt", OUT / "PHOTO-LICENSE.txt")

NAVY = "162E39"
CREAM = "FBF6ED"
GOLD = "B78648"
MUTED = "576D72"
PALE = "EDE4D5"


def scene(height):
    items = [
        ("text", "בס״ד", 362, 27, 70, 19, 12, "D9C6AB", False),
        ("text", "שנה חמישית", 110, 85, 574, 31, 23, "EAD1A0", False),
        ("text", "שירת", 60, 139, 674, 75, 65, "EAD1A0", True),
        ("text", "הבקשות", 90, 206, 614, 111, 101, "EAD1A0", True),
        ("text", "ליל שבת • פרשת לך לך", 100, 362, 594, 47, 32, CREAM, True),
        ("text", "בשעה 20:30", 100, 421, 594, 66, 48, "EAD1A0", True),
        ("text", "בית הכנסת אוצרות חיים", 100, 540, 594, 44, 33, CREAM, True),
        ("text", "רח׳ רבי יהודה הנשיא 20, פתח תקווה", 105, 590, 584, 36, 22, CREAM, False),
        ("text", "דברי תורה", 100, 670, 594, 28, 18, "D9C6AB", False),
        ("text", "הרב יוסף עיני", 100, 704, 594, 45, 36, CREAM, True),
        ("text", "עם פייטני הקהילה", 100, 769, 594, 32, 20, CREAM, False),
        ("text", "כיבוד קל", 100, 810, 594, 27, 18, "D9C6AB", False),
        ("qr", 60, 858, 88),
        ("text", "וואטסאפ לעדכונים", 36, 950, 136, 16, 10, "D9C6AB", False),
        ("text", "לעילוי נשמת מנחם יעקב בן מונירה ז״ל • ארי ציון בן שמחה ז״ל",
         44, 978, 706, 13, 9, "D9C6AB", False),
    ]
    if ALTERNATIVE:
        items = [
            ("text", "בס״ד", 362, 27, 70, 19, 12, "D9C6AB", False),
            ("text", "שנה חמישית", 297, 92, 200, 35, 22, "EAD1A0", False),
            ("text", "שירת הבקשות", 70, 171, 654, 128, 88, "EAD1A0", True),
            ("text", "ליל שבת", 109, 367, 263, 29, 18, "D9C6AB", False),
            ("text", "פרשת לך לך", 109, 402, 263, 59, 33, CREAM, True),
            ("text", "בשעה", 422, 367, 263, 29, 18, "D9C6AB", False),
            ("text", "20:30", 422, 399, 263, 68, 55, "EAD1A0", True),
            ("text", "בית הכנסת", 112, 535, 570, 29, 18, "D9C6AB", False),
            ("text", "אוצרות חיים", 112, 568, 570, 47, 37, CREAM, True),
            ("text", "רח׳ רבי יהודה הנשיא 20, פתח תקווה", 112, 622, 570, 28, 19, CREAM, False),
            ("text", "דברי תורה", 105, 711, 422, 28, 18, "D9C6AB", False),
            ("text", "הרב יוסף עיני", 105, 746, 422, 45, 35, CREAM, True),
            ("text", "עם פייטני הקהילה", 105, 816, 422, 29, 19, CREAM, False),
            ("text", "כיבוד קל", 105, 855, 422, 27, 17, "D9C6AB", False),
            ("qr", 60, 858, 88),
            ("text", "וואטסאפ לעדכונים", 36, 950, 136, 16, 10, "D9C6AB", False),
            ("text", "לעילוי נשמת מנחם יעקב בן מונירה ז״ל • ארי ציון בן שמחה ז״ל",
             44, 978, 706, 13, 9, "D9C6AB", False),
        ]
    if REFERENCE_STYLE:
        items = [
            ("text", "בס״ד", 362, 27, 70, 19, 12, "D9C6AB", False),
            ("text", "שירת", 110, 151, 574, 81, 73, CREAM, True),
            ("text", "הבקשות", 90, 224, 614, 117, 108, CREAM, True),
            ("text", "שנה חמישית", 227, 381, 340, 36, 25, NAVY, True),
            ("text", "ליל שבת • פרשת לך לך", 196, 477, 402, 47, 29, NAVY, True),
            ("text", "דברי תורה", 160, 568, 474, 28, 18, "D9C6AB", False),
            ("text", "הרב יוסף עיני", 160, 602, 474, 45, 37, CREAM, True),
            ("text", "עם פייטני הקהילה", 160, 660, 474, 29, 19, CREAM, False),
            ("text", "כיבוד קל", 160, 698, 474, 26, 17, "D9C6AB", False),
            ("text", "בשעה", 145, 754, 265, 25, 16, "D9C6AB", False),
            ("text", "20:30", 145, 784, 265, 65, 54, "EAD1A0", True),
            ("text", "בית הכנסת", 445, 760, 261, 26, 16, "D9C6AB", False),
            ("text", "אוצרות חיים", 445, 795, 261, 41, 29, CREAM, True),
            ("text", "רח׳ רבי יהודה הנשיא 20, פתח תקווה", 112, 854, 570, 29, 19, CREAM, False),
            ("qr", 60, 889, 73),
            ("text", "וואטסאפ לעדכונים", 30, 965, 133, 12, 9, "D9C6AB", False),
            ("text", "לעילוי נשמת מנחם יעקב בן מונירה ז״ל • ארי ציון בן שמחה ז״ל",
             44, 978, 706, 13, 9, "D9C6AB", False),
        ]
        if VARIANT in ("royal-arch", "piyut-scroll"):
            title_color = "EAD1A0" if VARIANT == "royal-arch" else NAVY
            items = [
                item[:7] + (title_color,) + item[8:]
                if item[0] == "text" and item[1] in ("שירת", "הבקשות") else item
                for item in items
            ]
    if VARIANT == "gold-medallion":
        adjusted = []
        for item in items:
            if item[0] != "text":
                adjusted.append(item)
                continue
            text = item[1]
            if text == "שנה חמישית":
                adjusted.extend([
                    ("text", "5", 353, 355, 88, 77, 70, "F0D5A0", True),
                    ("text", "שנה", 449, 386, 82, 28, 20, "F0D5A0", False),
                ])
            elif text == "בס״ד":
                adjusted.append(("text", text, 676, 27, 70, 19, 12, "D9C6AB", False))
            elif text == "בית הכנסת":
                adjusted.append(("text", text, 150, 754, 494, 25, 16, "D9C6AB", False))
            elif text == "אוצרות חיים":
                adjusted.append(("text", text, 112, 784, 570, 59, 48, "F0D5A0", True))
            elif text == "בשעה":
                adjusted.append(("text", text, 214, 891, 250, 23, 16, "D9C6AB", False))
            elif text == "20:30":
                adjusted.append(("text", text, 214, 918, 250, 49, 41, "F0D5A0", True))
            elif text == "עם פייטני הקהילה":
                adjusted.append(("text", "עם פייטנים וחזנים", 160, 660, 474, 29, 20, CREAM, False))
            else:
                adjusted.append(item)
        items = adjusted
    if COMPACT:
        items = [
            ("text", "בס״ד", 676, 22, 70, 19, 12, "D9C6AB", False),
            ("text", "שירת", 145, 109, 504, 56, 49, CREAM, True),
            ("text", "הבקשות", 140, 166, 514, 101, 88, CREAM, True),
            ("text", "5", 353, 278, 88, 65, 65, "F0D5A0", True),
            ("text", "שנה", 449, 308, 82, 25, 18, "F0D5A0", False),
            ("text", "ליל שבת • פרשת לך לך", 190, 378, 414, 39, 25, NAVY, True),
            ("text", "בשעה 20:30", 145, 434, 504, 48, 37, "F0D5A0", True),
            ("text", "בית הכנסת", 112, 498, 570, 24, 16, "D9C6AB", False),
            ("text", "אוצרות חיים", 112, 526, 570, 57, 49, "F0D5A0", True),
            ("text", "רח׳ רבי יהודה הנשיא 20, פתח תקווה", 112, 588, 570, 28, 20, CREAM, False),
            ("text", "עם פייטנים וחזנים", 130, 626, 534, 29, 21, CREAM, False),
            ("text", "דברי תורה", 140, 667, 514, 24, 15, "D9C6AB", False),
            ("text", "הרב יוסף עיני", 140, 696, 514, 34, 29, CREAM, True),
            ("text", "כיבוד קל", 145, 744, 504, 22, 15, "D9C6AB", False),
            ("qr", 30, 680, 66),
            ("text", "וואטסאפ לעדכונים", 20, 752, 86, 13, 8, "D9C6AB", False),
            ("text", "לעילוי נשמת מנחם יעקב בן מונירה ז״ל • ארי ציון בן שמחה ז״ל",
             44, 779, 706, 12, 8, "D9C6AB", False),
        ]
    if A4_LAYOUT:
        items = [
            ("text", "בס״ד", 676, 27, 70, 19, 12, "D9C6AB", False),
            ("text", "שירת", 110, 133, 574, 85, 71, CREAM, True),
            ("text", "הבקשות", 90, 213, 614, 112, 107, CREAM, True),
            ("text", "5", 320, 302, 100, 105, 100, "F0D5A0", True),
            ("text", "שנה", 382, 343, 66, 38, 28, "F0D5A0", False),
            ("text", "ליל שבת", 418, 464, 245, 32, 22, NAVY, False),
            ("text", "פרשת לך לך", 418, 495, 245, 64, 49, NAVY, True),
            ("text", "בשעה", 131, 464, 245, 32, 22, NAVY, False),
            ("text", "20:30", 131, 496, 245, 64, 68, NAVY, True),
            ("text", "בית הכנסת", 112, 596, 570, 36, 23, "D9C6AB", False),
            ("text", "אוצרות חיים", 95, 640, 604, 88, 71, "F0D5A0", True),
            ("text", "רח׳ רבי יהודה הנשיא 20, פתח תקווה", 112, 737, 570, 40, 27, CREAM, False),
            ("text", "דברי תורה", 152, 819, 490, 34, 22, "D9C6AB", False),
            ("text", "הרב יוסף עיני", 152, 859, 490, 58, 43, CREAM, True),
            ("text", "עם פייטנים וחזנים", 152, 933, 490, 40, 26, CREAM, False),
            ("text", "כיבוד קל", 152, 985, 490, 34, 22, "D9C6AB", False),
            ("qr", 158, 974, 88),
            ("text", "וואטסאפ לעדכונים", 137, 1068, 130, 24, 12, "D9C6AB", False),
            ("text", "לעילוי נשמת מנחם יעקב בן מונירה ז״ל • ארי ציון בן שמחה ז״ל",
             44, 1098, 706, 17, 10, "D9C6AB", False),
        ]
    if LANDSCAPE:
        panel_shift = 15 if STARRY else 0
        items = [
            ("text", "בס״ד", 713, 16, 58, 17, 10, "D9C6AB", False),
            ("text", "שירת", 424, 95, 330, 62, 49, CREAM, False),
            ("text", "הבקשות", 424, 155, 330, 87, 66, CREAM, False),
            ("text", "5", 530, 267, 84, 94, 82, "F0D5A0", True),
            ("text", "שנה", 588, 313, 50, 32, 24, "F0D5A0", False),
            ("text", "ליל שבת", 228, 61 - panel_shift, 169, 28, 17, NAVY, False),
            ("text", "פרשת לך לך", 228, 94 - panel_shift, 169, 48, 35, NAVY, True),
            ("text", "בשעה", 45, 61 - panel_shift, 169, 28, 17, NAVY, False),
            ("text", "20:30", 45, 95 - panel_shift, 169, 48, 49, NAVY, True),
            ("text", "בית הכנסת", 40, 156, 362, 25, 16, "D9C6AB", False),
            ("text", "אוצרות חיים", 40, 178, 362, 62, 47, "F0D5A0", True),
            ("text", "רח׳ רבי יהודה הנשיא 20, פתח תקווה", 40, 237, 362, 30, 18, CREAM, False),
            ("text", "עם פייטנים וחזנים", 40, 290, 362, 35, 22, CREAM, False),
            ("text", "דברי תורה", 40, 329, 362, 25, 16, "D9C6AB", False),
            ("text", "הרב יוסף עיני", 40, 353, 362, 46, 33, CREAM, True),
            ("text", "כיבוד קל", 40, 399, 362, 27, 16, "D9C6AB", False),
            ("qr", 706 if STARRY else 499, 354 if STARRY else 378, 48),
            ("text", "וואטסאפ לעדכונים", 685 if STARRY else 553, 407 if STARRY else 388,
             90 if STARRY else 170, 15 if STARRY else 28, 9 if STARRY else 11, "D9C6AB", False),
            ("text", "לעילוי נשמת מנחם יעקב בן מונירה ז״ל • ארי ציון בן שמחה ז״ל",
             44, 433, 706, 12, 7, "D9C6AB", False),
        ]
    items = [(item[0], "רבי יהודה הנשיא 20, פתח תקווה", *item[2:])
             if item[0] == "text" and item[1] == "רח׳ רבי יהודה הנשיא 20, פתח תקווה"
             else item for item in items]
    if args.browser_fonts:
        adjusted = []
        for item in items:
            if item[0] != "text":
                adjusted.append(item)
                continue
            kind, text, x, y, w, h, size, color, bold = item
            field = WEEKLY_FIELDS.get(text)
            override = BROWSER_LAYOUT.get("Wide" if LANDSCAPE else "A4", {}).get(
                field[0] if field else text, {}
            )
            x, y, w, h = override.get("bounds", (x, y, w, h))
            size = override.get("size", size)
            if text == "פרשת לך לך":
                size = 49.53 if LANDSCAPE else 68.73
                if LANDSCAPE:
                    x, w = x + w / 2 - 88, 176
            adjusted.append((kind, text, x, y, w, h, size, color, bold))
        items = adjusted
    if WEEKLY_TEMPLATE or args.browser_fonts:
        items = [(item[0], "ליל שבת • פרשת", *item[2:])
                 if item[0] == "text" and item[1] == "ליל שבת" else item for item in items]
    scale = height / (447 if LANDSCAPE else 1123 if A4_LAYOUT else 794 if COMPACT else 993)
    result = []
    for item in items:
        if item[0] == "text":
            kind, text, x, y, w, h, size, color, bold = item
            result.append((kind, text, x, y * scale, w, h * scale, size, color, bold))
        else:
            kind, x, y, size = item
            result.append((kind, x, y * scale, size))
    return result


def rgb(value):
    return RGBColor.from_string(value)


def text_font(text):
    display = text in (
        "שירת", "הבקשות", "שירת הבקשות", "שנה חמישית", "5",
        "בית הכנסת אוצרות חיים", "אוצרות חיים", "הרב יוסף עיני", "פרשת לך לך", "20:30", "שנה"
    )
    if args.browser_fonts:
        return "FrankRuehl" if display else "Arial"
    return "Frank Ruhl Libre" if display else "Heebo"


def ornament(cx, cy, width=120):
    paths = []
    for mirror in (-1, 1):
        paths.append([
            (cx + mirror * width * t / 60, cy + 7 * math.sin(t * math.pi / 30) * (1 - t / 72))
            for t in range(61)
        ])
        for offset in (25, 49, 77):
            x = cx + mirror * width * offset / 100
            paths.append([
                (x + mirror * 16 * math.sin(t * math.pi / 40),
                 cy - 18 * math.sin(t * math.pi / 20))
                for t in range(41)
            ])
    paths.append([(cx, cy - 8), (cx + 5, cy), (cx, cy + 8), (cx - 5, cy), (cx, cy - 8)])
    return paths


def lattice_paths(x, top, bottom, half_width):
    return [
        [(x + mirror * half_width * math.sin(math.pi * (y - top) / 46), y)
         for y in range(top, bottom + 1)]
        for mirror in (-1, 1)
    ]


def decoration_paths(height):
    scale = height / 993
    if LANDSCAPE:
        paths = [title_arch(height), title_arch(height, 10)]
        for mirror in (-1, 1):
            paths.append([(221 + mirror * 75 * t,
                           (277 + 7 * math.sin(2 * math.pi * t)) * height / 447)
                          for t in (step / 50 for step in range(51))])
        for x in (16, 778):
            for motif in lattice_paths(x, 50, 425, 12):
                paths.append([(px, py * height / 447) for px, py in motif])
        return paths
    if REFERENCE_STYLE:
        paths = []
        positions = ((93, 150), (379, 105), (705, 80)) if A4_LAYOUT else ((113, 150), (449, 105), (544, 80))
        for cy, width in positions:
            for mirror in (-1, 1):
                paths.append([
                    (397 + mirror * width * t, (cy + 12 * math.sin(2 * math.pi * t)) * scale)
                    for t in (step / 60 for step in range(61))
                ])
                paths.append([
                    (397 + mirror * (width * .68 + 15 * (1 - t) * math.cos(4 * math.pi * t)),
                     (cy - 10 + 15 * (1 - t) * math.sin(4 * math.pi * t)) * scale)
                    for t in (step / 80 for step in range(81))
                ])
        if VARIANT != "gold-medallion":
            paths.extend([
                [(125, 741 * scale), (669, 741 * scale)],
                [(426, 760 * scale), (426, 836 * scale)],
            ])
        if VARIANT != "piyut-scroll":
            paths.extend([title_arch(height), title_arch(height, 10)])
        if VARIANT == "royal-arch":
            for mirror in (-1, 1):
                for y in (173, 276, 331):
                    paths.append([
                        (397 + mirror * (277 + 12 * math.sin(t * math.pi)),
                         (y + 17 * math.cos(t * math.pi)) * scale)
                        for t in (step / 40 for step in range(41))
                    ])
        if VARIANT == "gold-medallion":
            for angle in range(195, 346, 15):
                a = math.radians(angle)
                paths.append([
                    (397 + 285 * math.cos(a), (250 + 200 * math.sin(a)) * scale),
                    (397 + 292 * math.cos(a), (250 + 208 * math.sin(a)) * scale),
                    (397 + 285 * math.cos(a), (250 + 200 * math.sin(a)) * scale),
                ])
            for x in (16, 778):
                paths.extend(lattice_paths(x, 50, height - 22, 12))
            if A4_LAYOUT:
                paths.extend(musical_heading_paths(height))
        if VARIANT == "gold-medallion":
            return paths
        for offset in range(5):
            paths.append([
                (310 + 300 * t, (921 - 40 * t + 12 * math.sin(math.pi * t) + offset * 7) * scale)
                for t in (step / 60 for step in range(61))
            ])
        for x, y in ((357, 930), (432, 922), (510, 909), (582, 895)):
            paths.append([(x + 7 * math.cos(a * math.pi / 30),
                           (y + 4 * math.sin(a * math.pi / 30)) * scale) for a in range(61)])
            paths.append([(x + 6, y * scale), (x + 6, (y - 27) * scale)])
        return paths
    positions = ((323, 105), (680, 60)) if ALTERNATIVE else ((337, 105), (509, 105))
    paths = [
        path
        for cy, width in positions
        for path in ornament(397, cy * scale, width)
    ]
    if ALTERNATIVE:
        for x, y, w, h in ((105, 351, 584, 126), (111, 518, 572, 140)):
            paths.append([(x, y * scale), (x + w, y * scale),
                          (x + w, (y + h) * scale), (x, (y + h) * scale),
                          (x, y * scale)])
        paths.append([(397, 368 * scale), (397, 462 * scale)])
        paths.append([(297, 135 * scale), (497, 135 * scale)])
    return paths


def title_arch(height, inset=0):
    scale = height / 993
    if LANDSCAPE:
        return [(589 + (156 - inset) * (1 + .055 * math.cos(8*a)) * math.cos(a),
                 (209 + (157 - inset) * (1 + .055 * math.cos(8*a)) * math.sin(a)) * height / 447)
                for a in (step * math.pi / 180 for step in range(361))]
    if A4_LAYOUT:
        return [(397 + (278 - inset) * math.cos(math.radians(a)),
                 (212 + (176 - inset) * math.sin(math.radians(a))) * height / 1123)
                for a in range(361)]
    if VARIANT == "gold-medallion":
        return [(397 + (278 - inset) * math.cos(math.radians(a)),
                 (250 + (192 - inset) * math.sin(math.radians(a))) * scale)
                for a in range(361)]
    points = [(133 + inset, 404), (133 + inset, 235)]
    points.extend((397 + (264 - inset) * math.cos(math.radians(a)),
                   235 + (166 - inset) * math.sin(math.radians(a))) for a in range(180, 361))
    points.append((661 - inset, 404))
    return [(x, y * scale) for x, y in points]


def panel_dividers(height):
    if not A4_LAYOUT and not LANDSCAPE:
        return []
    x, top, bottom, base = (221, 68, 138, 447) if LANDSCAPE else (397, 474, 548, 1123)
    if LANDSCAPE and STARRY:
        top -= 15
        bottom -= 15
    middle = (top + bottom) / 2
    paths = [[(x, top), (x, middle - 11)], [(x, middle + 11), (x, bottom)],
             [(x, middle - 7), (x + 5, middle), (x, middle + 7), (x - 5, middle), (x, middle - 7)]]
    for mirror in (-1, 1):
        paths.append([(x + mirror * 5 * math.sin(t * math.pi),
                       middle + 10 * math.cos(t * math.pi)) for t in (step / 40 for step in range(41))])
    return [[(px, py * height / base) for px, py in path] for path in paths]


def photo_placement(height, monochrome=False):
    if args.browser_fonts:
        variant_layout = BROWSER_LAYOUT["Wide" if LANDSCAPE else "A4"]
        if monochrome and A4_LAYOUT:
            variant_layout = {**variant_layout, **BROWSER_LAYOUT.get("A4-Black-and-White", {})}
        x, y, w, h = variant_layout["oud"]["bounds"]
        factor = height / (447 if LANDSCAPE else 1123)
        return x, y * factor, w, h * factor
    if A4_LAYOUT:
        return 561, 812 * height / 1123, 174, 291 * height / 1123
    if LANDSCAPE:
        if STARRY:
            return 405, 170 * height / 447, 125, 209 * height / 447
        return 431, 234 * height / 447, 85, 142 * height / 447
    return None


def musical_heading_paths(height):
    segments = [
        ((232, 117), (267, 86), (267, 150), (228, 191)),
        ((228, 191), (198, 220), (199, 251), (228, 253)),
        ((228, 253), (260, 252), (255, 217), (232, 217)),
        ((232, 217), (218, 217), (215, 231), (222, 238)),
        ((238, 103), (218, 137), (220, 178), (235, 214)),
        ((235, 214), (251, 255), (248, 272), (227, 271)),
    ]
    paths = []
    for p0, p1, p2, p3 in segments:
        paths.append([
            (sum(c * p[0] for c, p in zip(((1-t)**3, 3*(1-t)**2*t, 3*(1-t)*t*t, t**3), (p0, p1, p2, p3))),
             sum(c * p[1] for c, p in zip(((1-t)**3, 3*(1-t)**2*t, 3*(1-t)*t*t, t**3), (p0, p1, p2, p3))) * height / 1123)
            for t in (step / 40 for step in range(41))
        ])
    for x, y in ((565, 155), (592, 130), (610, 114)):
        paths.append([(x + 7 * math.cos(a), (y + 4 * math.sin(a)) * height / 1123)
                      for a in (step * math.pi / 30 for step in range(61))])
        paths.append([(x + 6, y * height / 1123), (x + 6, (y - 26) * height / 1123)])
    return paths


def ribbon_polygons(height):
    if not REFERENCE_STYLE:
        return []
    scale = height / 993
    if LANDSCAPE:
        panel = [(39, 55), (389, 55), (403, 69), (403, 151), (53, 151), (39, 137)]
        shift = 15 if STARRY else 0
        return [([(x, (y - shift) * height / 447) for x, y in panel], CREAM)]
    if A4_LAYOUT:
        scale = height / 1123
        band = [(193 + 408 * t, 335 - 7 * math.sin(math.pi * t))
                for t in (step / 60 for step in range(61))]
        band += [(193 + 408 * t, 393 - 7 * math.sin(math.pi * t))
                 for t in (step / 60 for step in range(60, -1, -1))]
        left = [(139, 325), (219, 342), (219, 387), (139, 381), (156, 355)]
        right = [(794 - x, y) for x, y in left]
        parashah = [(112, 456), (668, 456), (682, 470), (682, 564), (126, 564), (112, 550)]
        return [([(x, y * scale) for x, y in points], color)
                for points, color in ((left, "A67C3B"), (right, "A67C3B"),
                                      (band, "173A35"), (parashah, CREAM))]
    band = [(193 + 408 * t, 374 - 7 * math.sin(math.pi * t))
            for t in (step / 60 for step in range(61))]
    band += [(193 + 408 * t, 428 - 7 * math.sin(math.pi * t))
             for t in (step / 60 for step in range(60, -1, -1))]
    left_tail = [(139, 363), (219, 381), (219, 421), (139, 415), (156, 392)]
    right_tail = [(794 - x, y) for x, y in left_tail]
    parashah = [(184, 475), (599, 475), (611, 487), (611, 522),
                (196, 522), (184, 510)]
    polygons = [
        ([(x, y * scale) for x, y in points], color)
        for points, color in ((left_tail, "A67C3B"), (right_tail, "A67C3B"),
                              (band, "173A35" if VARIANT == "gold-medallion" else "DCC08A"),
                              (parashah, CREAM))
    ]
    if VARIANT == "royal-arch":
        crown = [(366, 79), (359, 53), (377, 66), (397, 44), (417, 66), (435, 53), (428, 79)]
        polygons.append(([(x, y * scale) for x, y in crown], "DCC08A"))
    elif VARIANT == "piyut-scroll":
        top = [(151 + 492 * t, 140 + 13 * math.sin(math.pi * t))
               for t in (step / 60 for step in range(61))]
        bottom = [(151 + 492 * t, 350 + 13 * math.sin(math.pi * t))
                  for t in (step / 60 for step in range(60, -1, -1))]
        left_roll = [(132, 136), (170, 145), (170, 357), (132, 366)]
        right_roll = [(794 - x, y) for x, y in left_roll]
        polygons = [
            ([(x, y * scale) for x, y in points], color)
            for points, color in ((left_roll, "BA955A"), (right_roll, "BA955A"),
                                  (top + bottom, CREAM))
        ] + polygons
    return polygons


def oud_paths(height):
    def curve(start, control1, control2, end):
        return [
            tuple((1 - t) ** 3 * start[i] + 3 * (1 - t) ** 2 * t * control1[i]
                  + 3 * (1 - t) * t ** 2 * control2[i] + t ** 3 * end[i]
                  for i in (0, 1))
            for t in (step / 30 for step in range(31))
        ]

    body = (
        curve((0, -53), (-12, -54), (-34, -36), (-43, -3))
        + curve((-43, -3), (-61, 60), (-5, 89), (25, 66))
        + curve((25, 66), (60, 40), (48, -8), (22, -41))
        + curve((22, -41), (16, -50), (11, -53), (0, -53))
    )
    paths = [
        body,
        [(0, -53), (0, -105), (15, -105), (17, -53)],
        [(0, -105), (-11, -128), (1, -132), (15, -105)],
        [(-13, 42), (28, 42), (28, 48), (-13, 48), (-13, 42)],
    ]
    for cx, cy, radius in ((5, -5, 13), (-17, -25, 6), (24, -25, 6)):
        for inset in (0, 2):
            paths.append([
                (cx + (radius - inset) * math.cos(a * math.pi / 30),
                 cy + (radius - inset) * math.sin(a * math.pi / 30))
                for a in range(61)
            ])
        for angle in range(0, 180, 30):
            a = math.radians(angle)
            paths.append([(cx - radius * .75 * math.cos(a), cy - radius * .75 * math.sin(a)),
                          (cx + radius * .75 * math.cos(a), cy + radius * .75 * math.sin(a))])
    for string in range(6):
        x = 2 + string * 2
        paths.append([(x, -106), (x + 2, 43)])
    for y in (-111, -118, -125):
        paths.extend([[(-9, y), (-17, y)], [(7, y), (15, y)]])
    angle = math.radians(17)
    scale = height / 993
    return [
        [(687 + 1.08 * (x * math.cos(angle) - y * math.sin(angle)),
          (846 + 1.08 * (x * math.sin(angle) + y * math.cos(angle))) * scale)
         for x, y in path]
        for path in paths
    ]


def illustrated_background(height, monochrome=False):
    factor = 3
    image = Image.new("RGB", (794 * factor, height * factor))
    draw = ImageDraw.Draw(image)
    for y in range(height * factor):
        t = y / (height * factor)
        draw.line((0, y, 794 * factor, y),
                  fill=(int(11 + 18 * t), int(29 + 8 * t), int(40 - 5 * t)))
    glow = Image.new("RGBA", image.size)
    gd = ImageDraw.Draw(glow)
    for x, y, radius, color in ((397, 207, 250, (51, 111, 110, 95)),
                                (20, 300, 140, (141, 76, 41, 90)),
                                (774, 300, 140, (141, 76, 41, 90))):
        gd.ellipse(((x - radius) * factor, (y - radius) * factor,
                    (x + radius) * factor, (y + radius) * factor), fill=color)
    if VARIANT == "gold-medallion":
        for x in (18, 776):
            y, radius = height * .73, 170
            gd.ellipse(((x - radius) * factor, (y - radius) * factor,
                        (x + radius) * factor, (y + radius) * factor),
                       fill=(202, 145, 52, 115))
    image = Image.alpha_composite(image.convert("RGBA"), glow.filter(ImageFilter.GaussianBlur(47 * factor)))
    if STARRY and not monochrome:
        rng = random.Random(28)
        stars = Image.new("RGBA", image.size)
        halos = Image.new("RGBA", image.size)
        sd, hd = ImageDraw.Draw(stars), ImageDraw.Draw(halos)
        text_bounds = [(item[2] - 5, item[3] - 5, item[2] + item[4] + 5, item[3] + item[5] + 5)
                       for item in scene(height) if item[0] == "text"]
        for _ in range(round(794 * height / 650)):
            x, y = rng.uniform(10, 784), rng.uniform(10, height - 10)
            quiet = any(left <= x <= right and top <= y <= bottom
                        for left, top, right, bottom in text_bounds)
            bright = rng.random() < .12
            radius = rng.uniform(.55, .95) if bright else rng.uniform(.22, .52)
            opacity = round(rng.uniform(170, 245) if bright else rng.uniform(95, 190))
            if quiet:
                opacity = round(opacity * .18)
            color = rng.choice(((230, 237, 247), (247, 239, 215), (205, 222, 236)))
            sd.ellipse(((x - radius) * factor, (y - radius) * factor,
                        (x + radius) * factor, (y + radius) * factor), fill=(*color, opacity))
            if bright and not quiet:
                spread = radius * 5
                hd.ellipse(((x - spread) * factor, (y - spread) * factor,
                            (x + spread) * factor, (y + spread) * factor), fill=(*color, 65))
        image = Image.alpha_composite(image, halos.filter(ImageFilter.GaussianBlur(3 * factor)))
        image = Image.alpha_composite(image, stars.filter(ImageFilter.GaussianBlur(.18 * factor)))
    if monochrome:
        image = Image.new("RGB", image.size, "white")
    draw = ImageDraw.Draw(image)

    def line(points, color=GOLD, width=1):
        if monochrome:
            color, width = "000000", max(1.4, min(width, 2))
        draw.line([(int(x * factor), int(y * factor)) for x, y in points],
                  fill=f"#{color}", width=max(1, int(width * factor)), joint="curve")

    def ellipse(box, fill, outline=None, width=1):
        draw.ellipse(tuple(int(v * factor) for v in box), fill=fill, outline=outline,
                     width=int(width * factor))

    if not REFERENCE_STYLE:
        for mirror in (-1, 1):
            cx = 397 + mirror * 321
            line([(cx + mirror * 8 * math.sin(t / 25), 125 + t) for t in range(height - 265)], "A58A56", .8)
            for y in range(150, height - 145, 76):
                for side in (-1, 1):
                    points = [(cx + side * 23 * math.sin(t * math.pi / 50),
                               y - 25 * math.sin(t * math.pi / 100))
                              for t in range(101)]
                    line(points, "9E8050", .65)
            for offset in (0, 8):
                arch = [(123 - offset, height - 65), (123 - offset, 283)]
                arch.extend((397 + (274 + offset) * math.cos(math.radians(a)),
                             283 + (231 + offset) * math.sin(math.radians(a)))
                            for a in range(180, 361))
                arch.append((671 + offset, height - 65))
                line(arch, "AD8B54" if offset else "D7BA80", .65 if offset else 1.2)
        draw.rectangle((24 * factor, 24 * factor, 770 * factor, (height - 24) * factor),
                       outline="#C79A54", width=factor)
        draw.rectangle((30 * factor, 30 * factor, 764 * factor, (height - 30) * factor),
                       outline="#826B46", width=factor)
    for path in decoration_paths(height):
        line(path, "D7BA80", .8)
    if REFERENCE_STYLE and VARIANT != "piyut-scroll":
        line(title_arch(height), "78582B", 7 if LANDSCAPE else 17)
        line(title_arch(height), "C6A266", 4 if LANDSCAPE else 11)
        line(title_arch(height, -3 if LANDSCAPE else -6), "E3C994", .8 if LANDSCAPE else 1.2)
        line(title_arch(height, 3 if LANDSCAPE else 6), "F1DFC0", .8 if LANDSCAPE else 1.4)
        line(title_arch(height, 8 if LANDSCAPE else 13), "A48957", .6 if LANDSCAPE else 1)
        for x in (() if A4_LAYOUT or LANDSCAPE else (133, 661)):
            for y in (228, 239, 349, 360):
                line([(x - 12, y * height / 993), (x + 12, y * height / 993)], "DCC08A", 3)
    for points, color in ribbon_polygons(height):
        draw.polygon([(int(x * factor), int(y * factor)) for x, y in points],
                     fill="white" if monochrome else f"#{color}")
        line(points + [points[0]], "EBD8B2", .9)
    if A4_LAYOUT:
        for path in musical_heading_paths(height):
            line(path, "EAD1A0", 1.8)
    for path in panel_dividers(height):
        line(path, GOLD, 1.2)
    instrument = [] if REFERENCE_STYLE else oud_paths(height)
    for index in (() if REFERENCE_STYLE else (0, 1, 2)):
        draw.polygon([(int(x * factor), int(y * factor)) for x, y in instrument[index]],
                     fill="#B58A4D" if index == 0 else "#826037")
    for index in (() if REFERENCE_STYLE else (3, 4, 12, 20)):
        draw.polygon([(int(x * factor), int(y * factor)) for x, y in instrument[index]],
                     fill="#493A28")
    for index, path in enumerate(instrument):
        line(path, "F0D5A0", 1.4 if index == 0 else .9)
    return image.convert("RGB")


for height, name in ((1123, "A4"), (WHATSAPP_HEIGHT, "WhatsApp")):
    illustrated_background(height).save(OUT / f"Bakashot-background-{name}.png")
    if args.strong_print:
        illustrated_background(height, monochrome=True).save(
            OUT / f"Bakashot-background-{name}-Black-and-White.png"
        )


def presentation(height, name, background_only=False, monochrome=False):
    prs = Presentation()
    width_inches = 210 / 25.4 if A4_LAYOUT else 297 / 25.4 if monochrome else 8.27
    scale = width_inches / 794
    prs.slide_width = Inches(width_inches)
    prs.slide_height = Inches(width_inches * 9 / 16 if LANDSCAPE else 297 / 25.4 if A4_LAYOUT else 420 / 25.4 if monochrome else height * scale)
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = rgb("FFFFFF" if monochrome else CREAM)

    def shape(kind, x, y, w, h, color, line=None):
        obj = slide.shapes.add_shape(kind, Inches(x * scale), Inches(y * scale),
                                     Inches(w * scale), Inches(h * scale))
        obj.fill.solid()
        obj.fill.fore_color.rgb = rgb(color)
        obj.line.fill.background()
        if line:
            obj.line.color.rgb = rgb(line)
            obj.line.width = Pt(1)
        return obj

    flattened = WEEKLY_TEMPLATE and args.template_color_background is not None
    if flattened:
        background_path = args.template_print_background if monochrome else args.template_color_background
        picture = slide.shapes.add_picture(str(background_path), 0, 0, width=prs.slide_width, height=prs.slide_height)
        locks = picture._element.xpath(".//a:picLocks")[0]
        for attribute in ("noSelect", "noMove", "noResize"):
            locks.set(attribute, "1")
    elif monochrome and args.strong_print:
        picture = slide.shapes.add_picture(
            str(OUT / f"Bakashot-background-{'A4' if height == 1123 else 'WhatsApp'}-Black-and-White.png"),
            0, 0, width=prs.slide_width, height=prs.slide_height
        )
        locks = picture._element.xpath(".//a:picLocks")[0]
        for attribute in ("noSelect", "noMove", "noResize"):
            locks.set(attribute, "1")
    elif monochrome:
        if not REFERENCE_STYLE:
            shape(MSO_SHAPE.RECTANGLE, 27, 27, 740, height - 54, "FFFFFF", "000000").fill.background()
        for path in decoration_paths(height):
            builder = slide.shapes.build_freeform(*path[0], scale=Inches(scale))
            builder.add_line_segments(path[1:], close=False)
            flourish = builder.convert_to_shape()
            flourish.fill.background()
            flourish.line.color.rgb = rgb("000000")
            flourish.line.width = Pt(.7)
        for path in ([] if REFERENCE_STYLE else oud_paths(height)):
            builder = slide.shapes.build_freeform(*path[0], scale=Inches(scale))
            builder.add_line_segments(path[1:], close=False)
            instrument = builder.convert_to_shape()
            instrument.fill.background()
            instrument.line.color.rgb = rgb("000000")
            instrument.line.width = Pt(.6)
        for points, _ in ribbon_polygons(height):
            builder = slide.shapes.build_freeform(*points[0], scale=Inches(scale))
            builder.add_line_segments(points[1:], close=True)
            ribbon = builder.convert_to_shape()
            ribbon.fill.solid()
            ribbon.fill.fore_color.rgb = rgb("FFFFFF")
            ribbon.line.color.rgb = rgb("000000")
            ribbon.line.width = Pt(.8)
        for path in panel_dividers(height):
            builder = slide.shapes.build_freeform(*path[0], scale=Inches(scale))
            builder.add_line_segments(path[1:], close=False)
            divider = builder.convert_to_shape()
            divider.fill.background()
            divider.line.color.rgb = rgb("000000")
            divider.line.width = Pt(.8)
    else:
        slide.shapes.add_picture(str(OUT / f"Bakashot-background-{'A4' if height == 1123 else 'WhatsApp'}.png"),
                                 0, 0, width=prs.slide_width, height=prs.slide_height)
    placement = photo_placement(height, monochrome=monochrome)
    if placement and not flattened:
        x, y, w, h = placement
        slide.shapes.add_picture(str(OUT / ("oud-photo-gray.png" if monochrome else "oud-photo.png")),
                                 Inches(x * scale), Inches(y * scale),
                                 width=Inches(w * scale), height=Inches(h * scale))
    for item in scene(height):
        kind = item[0]
        if flattened and not (kind == "text" and item[1] in WEEKLY_FIELDS):
            continue
        if background_only and kind in ("text", "qr"):
            continue
        if kind == "text":
            _, text, x, y, w, h, size, color, bold = item
            box = slide.shapes.add_textbox(Inches(x * scale), Inches(y * scale),
                                          Inches(w * scale), Inches(h * scale))
            field = WEEKLY_FIELDS.get(text) if WEEKLY_TEMPLATE or args.browser_fonts else None
            box.name = field[0] if field else text
            tf = box.text_frame
            tf.clear()
            tf.word_wrap = True
            tf.margin_left = tf.margin_right = 0
            tf.margin_top = tf.margin_bottom = 0
            tf.vertical_anchor = MSO_ANCHOR.MIDDLE
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.CENTER
            pPr = p._p.get_or_add_pPr()
            pPr.set("rtl", "1")
            run = p.add_run()
            run.text = field[1] if field and args.browser_fonts else "" if field else text
            run.font.name = text_font(text)
            run.font.size = Pt(size * scale * 72)
            run.font.bold = bold
            run.font.color.rgb = rgb("000000" if monochrome else color)
            rPr = run._r.get_or_add_rPr()
            rPr.set("lang", "he-IL")
            cs = OxmlElement("a:cs")
            cs.set("typeface", text_font(text))
            rPr.append(cs)
            if args.browser_fonts:
                defaults = deepcopy(rPr)
                defaults.tag = "{http://schemas.openxmlformats.org/drawingml/2006/main}defRPr"
                pPr.append(defaults)
                insertion = deepcopy(rPr)
                insertion.tag = "{http://schemas.openxmlformats.org/drawingml/2006/main}endParaRPr"
                p._p.append(insertion)
        elif kind == "rect":
            _, x, y, w, h, color = item
            shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h, "FFFFFF" if monochrome else color,
                  "000000" if monochrome else None)
        elif kind == "line":
            _, x, y, w, color = item
            shape(MSO_SHAPE.RECTANGLE, x, y, w, 1, "000000" if monochrome else color)
        elif kind == "qr":
            _, x, y, size = item
            slide.shapes.add_picture(str(OUT / "whatsapp-qr.png"),
                                     Inches(x * scale), Inches(y * scale),
                                     width=Inches(size * scale), height=Inches(size * scale))
    slide.notes_slide.notes_text_frame.text = (
        "עדכון שבועי: ערכו את תיבות הטקסט של השנה, הפרשה, השעה, המקום, הכתובת ושם הרב. "
        "אפשר להחליף את השורה ״עם פייטני הקהילה״ בשם הפייטן, או להשאיר אותה ללא שם. "
        "כל תיבות הטקסט ניתנות לעריכה. האיור ברקע הוא תמונה נפרדת. "
        "קוד הוואטסאפ נלקח מהכרזה המקורית."
        " הגופנים Frank Ruhl Libre ו-Heebo מצורפים בתיקיית fonts."
    )
    if WEEKLY_TEMPLATE:
        slide.notes_slide.notes_text_frame.text = (
            "תבנית שבועית: רק שם הפרשה ושם הרב ניתנים לעריכה. "
            "כל שאר הפרטים והעיצוב קבועים בתמונת הרקע."
        )
    if placement:
        slide.notes_slide.notes_text_frame.text += "\n\n" + (OUT / "PHOTO-LICENSE.txt").read_text()
    prs.save(OUT / f"{name}.pptx")


def web_scene(height):
    background_data = base64.b64encode(
        (OUT / f"Bakashot-background-{'A4' if height == 1123 else 'WhatsApp'}.png").read_bytes()
    ).decode()
    parts = [
        f'<img class="artwork" alt="" src="data:image/png;base64,{background_data}" style="position:absolute;inset:0;width:794px;height:{height}px">',
        '<div class="print-border"></div><div class="print-rule"></div>',
    ]
    paths = "".join(
        '<polyline points="' + " ".join(f"{x:.2f},{y:.2f}" for x, y in path) + '"/>'
        for path in decoration_paths(height)
    )
    paths += "".join(
        '<polyline points="' + " ".join(f"{x:.2f},{y:.2f}" for x, y in path) + '"/>'
        for path in ([] if REFERENCE_STYLE else oud_paths(height))
    )
    paths += "".join(
        '<polygon fill="white" points="' + " ".join(f"{x:.2f},{y:.2f}" for x, y in points) + '"/>'
        for points, _ in ribbon_polygons(height)
    )
    paths += "".join(
        '<polyline points="' + " ".join(f"{x:.2f},{y:.2f}" for x, y in path) + '"/>'
        for path in panel_dividers(height)
    )
    parts.append(f'<svg class="print-ornament" viewBox="0 0 794 {height}" xmlns="http://www.w3.org/2000/svg">{paths}</svg>')
    placement = photo_placement(height)
    if placement:
        x, y, w, h = placement
        photo_data = base64.b64encode((OUT / "oud-photo.png").read_bytes()).decode()
        parts.append(f'<img class="hero-photo" alt="עוד מעוטר" src="data:image/png;base64,{photo_data}" '
                     f'style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px">')
    for item in scene(height):
        if item[0] == "text":
            _, text, x, y, w, h, size, color, bold = item
            field = WEEKLY_FIELDS.get(text) if WEEKLY_TEMPLATE else None
            editable = "true" if not WEEKLY_TEMPLATE or field else "false"
            field_attributes = (
                f'data-field="{field[0]}" data-placeholder="{html.escape(field[1])}" aria-label="{html.escape(field[1])}" '
                if field else ""
            )
            parts.append(
                f'<div class="text{" weekly-field" if field else ""}" contenteditable="{editable}" spellcheck="false" {field_attributes}'
                f'style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;'
                f'font-family:{html.escape(text_font(text))};font-size:{size}px;color:#{color};font-weight:{700 if bold else 400}">'
                f'{"" if field else html.escape(text)}</div>'
            )
        elif item[0] == "rect":
            _, x, y, w, h, color = item
            parts.append(f'<div class="pill" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;background:#{color}"></div>')
        elif item[0] == "line":
            _, x, y, w, color = item
            parts.append(f'<div class="rule" style="left:{x}px;top:{y}px;width:{w}px;background:#{color}"></div>')
        elif item[0] == "qr":
            _, x, y, size = item
            parts.append(f'<img alt="וואטסאפ לעדכונים" src="data:image/png;base64,{QR_DATA}" style="position:absolute;left:{x}px;top:{y}px;width:{size}px;height:{size}px">')
    return "".join(parts)


if not WEEKLY_TEMPLATE or args.template_color_background:
    if not COMPACT and not LANDSCAPE:
        presentation(1123, "Bakashot-A4-print-editable" if A4_LAYOUT else "Bakashot-A3-editable", monochrome=True)
    presentation(WHATSAPP_HEIGHT, "Bakashot-A4-color-editable" if A4_LAYOUT else "Bakashot-WhatsApp-editable")
    presentation(WHATSAPP_HEIGHT if COMPACT or LANDSCAPE else 1123, "Bakashot-background-editable", background_only=True)

document = """<!doctype html>
<html lang="he" dir="rtl">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>שירת הבקשות — תבנית לעריכה</title>
<style>
FONTS
* { box-sizing: border-box; }
body { margin:0; padding:24px; background:#e5e8e7; font-family:Arial,sans-serif; }
.controls { max-width:794px; margin:0 auto 20px; color:#162e39; line-height:1.6; }
button,select { font:inherit; padding:8px 14px; margin:4px; border:1px solid #b78648; border-radius:7px; background:#fbf6ed; cursor:pointer; }
.poster { position:relative; width:794px; height:1123px; margin:auto; overflow:hidden; background:#fbf6ed; box-shadow:0 12px 40px #162e3920; }
.night { position:absolute; inset:0 0 auto; height:443px; background:#162e39; }
.border { position:absolute; inset:27px; border:1px solid #b78648; z-index:1; pointer-events:none; }
.arch { position:absolute; left:118px; top:41px; width:558px; height:402px; border:1px solid #b78648; border-bottom:0; border-radius:280px 280px 0 0; }
.diamond { position:absolute; top:432px; width:12px; height:12px; transform:rotate(45deg); background:#b78648; }
.text { position:absolute; display:flex; justify-content:center; align-items:center; text-align:center; direction:rtl; line-height:1.08; white-space:pre-wrap; z-index:2; }
.text:focus { outline:2px dashed #b78648; outline-offset:5px; }
.weekly-field { outline:1px dashed #b78648; cursor:text; }
.weekly-field:empty::before { content:attr(data-placeholder); color:#b78648; font-family:Heebo,sans-serif; font-size:18px; font-weight:400; }
body.preview .weekly-field { outline:none; }
body.preview .weekly-field::before { display:none; }
.pill { position:absolute; border-radius:12px; }
.rule { position:absolute; height:1px; }
.print-border,.print-rule,.print-ornament { display:none; }
.monochrome .artwork { display:none; }
.monochrome { background:white; }
.monochrome .text { color:black !important; }
.monochrome .hero-photo { filter:grayscale(1); }
.monochrome .pill { background:white !important; border:1px solid black; }
.monochrome .rule { background:black !important; }
.monochrome .print-border { display:block; position:absolute; inset:27px; border:1px solid black; }
.reference-style .print-border { display:none; }
.monochrome .print-ornament { display:block; position:absolute; inset:0; width:100%; height:100%; fill:none; stroke:black; stroke-width:.8; pointer-events:none; }
@page { size:A3; margin:0; }
@media print {
  body { background:white; padding:0; }
  .controls { display:none; }
  .weekly-field { outline:none; }
  .weekly-field::before { display:none; }
  .poster { margin:0; box-shadow:none; zoom:1; }
  .poster.monochrome { zoom:1.4135; }
  * { print-color-adjust:exact; -webkit-print-color-adjust:exact; }
}
</style>
<div class="controls">
<strong>תבנית שבועית — שירת הבקשות</strong><br>
לחצו על הטקסט כדי לערוך פרשה, שעה, מקום, כתובת ושם הרב. אפשר להוסיף שם פייטן בשורה של חזני הקהילה.
שמרו את הקובץ לאחר העריכה כדי לשמור את השינויים.<br>
<select aria-label="גודל הכרזה" onchange="changeSize(this.value)">
<option value="a4">הדפסת A3 — שחור לבן</option><option value="whatsapp">וואטסאפ — צבעוני, יחס 4:5</option>
</select>
<button onclick="saveTemplate()">שמירת תבנית מעודכנת</button>
<button onclick="window.print()">הדפסה / PDF</button>
</div>
<main class="poster monochrome" id="poster">SCENE</main>
<style id="page-size">@page { size:A3; margin:0; }</style>
<script>
const layouts = LAYOUTS;
function changeSize(value) {
  const previous = [...document.querySelectorAll('.text')].map(el => el.innerText);
  const poster = document.getElementById('poster');
  poster.innerHTML = layouts[value];
  [...poster.querySelectorAll('.text')].forEach((el, i) => el.innerText = previous[i]);
  poster.style.height = value === 'a4' ? '1123px' : 'WHATSAPP_HEIGHTpx';
  poster.classList.toggle('monochrome', value === 'a4');
  document.getElementById('page-size').textContent =
    value === 'a4' ? '@page { size:A3; margin:0; }' : '@page { size:210mm 262.5mm; margin:0; }';
}
function saveTemplate() {
  const clone = document.documentElement.cloneNode(true);
  const select = clone.querySelector('select');
  [...select.options].forEach(option => option.toggleAttribute('selected', option.value === document.querySelector('select').value));
  const blob = new Blob(['<!doctype html>\\n' + clone.outerHTML], {type:'text/html;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Bakashot-edited.html';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
if (new URLSearchParams(location.search).get('preview')) {
  document.body.classList.add('preview');
  const format = new URLSearchParams(location.search).get('format') || 'a4';
  document.querySelector('select').value = format;
  changeSize(format);
  document.querySelector('.controls').style.display = 'none';
  document.body.style.padding = '0';
  document.body.style.background = '#fbf6ed';
  document.querySelector('.poster').style.boxShadow = 'none';
}
</script>
</html>
"""
document = document.replace("SCENE", web_scene(1123)).replace(
    "LAYOUTS", json.dumps({"a4": web_scene(1123), "whatsapp": web_scene(WHATSAPP_HEIGHT)}, ensure_ascii=False)
)
document = document.replace("WHATSAPP_HEIGHTpx", f"{WHATSAPP_HEIGHT}px")
if args.strong_print:
    document = document.replace("stroke-width:.8", "stroke-width:1.4").replace(
        "filter:grayscale(1);", "filter:grayscale(1) contrast(1.25);"
    )
if args.browser_fonts and A4_LAYOUT:
    x, y, w, h = photo_placement(1123, monochrome=True)
    document = document.replace("</style>", (
        f".monochrome .hero-photo {{ left:{x}px !important; top:{y}px !important; "
        f"width:{w}px !important; height:{h}px !important; }}\n</style>"
    ), 1)
if WEEKLY_TEMPLATE:
    document = document.replace(
        "לחצו על הטקסט כדי לערוך פרשה, שעה, מקום, כתובת ושם הרב. אפשר להוסיף שם פייטן בשורה של חזני הקהילה.",
        "רק שני השדות המסומנים ניתנים לעריכה: שם הפרשה ושם הרב. כל שאר הפרטים קבועים."
    )
if A4_LAYOUT or LANDSCAPE:
    document = document.replace('</div>\n<main', (
        '<p dir="ltr"><small>Oud photograph: '
        '<a href="https://commons.wikimedia.org/wiki/File:Oud_-_MIM_PHX.jpg">'
        'Frank Kovalchek</a>, '
        '<a href="https://creativecommons.org/licenses/by/2.0/">CC BY 2.0</a>. '
        'Background removed; resized; grayscale for print. '
        'Include this credit in accompanying text when sharing the image or PDF.'
        '</small></p></div>\n<main'
    ))
if COMPACT:
    document = document.replace('class="poster monochrome"', 'class="poster"')
    document = document.replace('<option value="a4">הדפסת A3 — שחור לבן</option>', '')
    document = document.replace("וואטסאפ — צבעוני, יחס 4:5", "וואטסאפ — ריבוע 1:1")
    document = document.replace("size:A3", "size:210mm 210mm")
    document = document.replace("size:210mm 262.5mm", "size:210mm 210mm")
    document = document.replace('id="poster">' + web_scene(1123), 'id="poster" style="height:794px">' + web_scene(794))
if A4_LAYOUT:
    document = document.replace("הדפסת A3", "הדפסת A4")
    document = document.replace("וואטסאפ — צבעוני, יחס 4:5", "כרזת A4 — צבעוני")
    document = document.replace("size:A3", "size:A4")
    document = document.replace("size:210mm 262.5mm", "size:A4")
    document = document.replace("zoom:1.4135", "zoom:.9995")
    document = document.replace("box-shadow:none; zoom:1;", "box-shadow:none; zoom:.9995;")
if LANDSCAPE:
    document = document.replace('class="poster monochrome"', 'class="poster"')
    document = document.replace('<option value="a4">הדפסת A3 — שחור לבן</option>', '')
    document = document.replace("וואטסאפ — צבעוני, יחס 4:5", "וואטסאפ — רוחבי 16:9")
    document = document.replace("size:A3", "size:210mm 118.125mm")
    document = document.replace("size:210mm 262.5mm", "size:210mm 118.125mm")
    document = document.replace('id="poster">' + web_scene(1123), 'id="poster" style="height:447px">' + web_scene(447))
if REFERENCE_STYLE:
    document = document.replace('class="poster monochrome"', 'class="poster monochrome reference-style"')
document = document.replace("FONTS", "\n".join(
    f"@font-face {{ font-family:'{name}'; src:url(data:font/ttf;base64,"
    f"{base64.b64encode((OUT / 'fonts' / filename).read_bytes()).decode()}) format('truetype'); "
    "font-weight:100 900; font-style:normal; }"
    for name, filename in (("Frank Ruhl Libre", "FrankRuhlLibre.ttf"), ("Heebo", "Heebo.ttf"))
))
(OUT / "Bakashot-editable.html").write_text(document)
print(f"Created editable templates in {OUT}")
